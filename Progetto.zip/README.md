# Comparazione tra Physarum Polycephalum Algorithm Based (PPAB) e A* per la risoluzione di problemi di path-finding

Implementazione di un'automa cellulare in grado di simulare il comportamento del Physarum Polycephalum, per la risoluzione di problemi di path-finding.
